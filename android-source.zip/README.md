# Pick Now Android companion

A small native Android WebView companion for the deployed private Pick Now website. The server still controls login, live data, model approval and NO BET. No password, API key, betting logic or wager automation is embedded. Android 8.0 (API 26) or newer is required.

## Security scope

Only the exact HTTPS app origin loads inside WebView. File/content access, cleartext and mixed content, third-party cookies, JavaScript bridges and WebView debugging are disabled. Certificate errors cancel loading. HTTPS links activated by the user can open in the external browser. The app accepts no launch URL or deep-link input. Back navigation, native retry, loading progress and connection messages are provided. Returning from the background reloads the dashboard so retained odds cannot appear current. The existing owner password is entered only in the website's HTTPS login page. Backup is disabled; first-party cookies live in the application's private WebView storage and the server expires sessions.

## Build

Pinned toolchain: JDK 17, Gradle 8.13, Android Gradle Plugin 8.13.2, compile/target SDK 36, SDK Build Tools 35.0.0. No external app libraries are required. With these tools installed and ANDROID_HOME set, run:

```
gradle --no-daemon assembleDebug lintDebug
```

The test APK is `app/build/outputs/apk/debug/app-debug.apk`. It uses Android's debug signing key and is intended for private testing, not Play Store distribution. Each clean CI runner generates a different debug key; later builds can require uninstall/reinstall, which clears app cookies. A persistent private release signing key is needed before ongoing update distribution; never commit that key.

The parent repository workflow builds the checked-in `android-source.zip` with a read-only GitHub token, without application credentials. APK build success and lint success do not substitute for running the app on a phone. Device acceptance: sign in, check live data, return after snapshot expiry, sign out, check offline/retry, follow a documentation link, rotate, and test Android back navigation.

## Validation status

Local environment initially had only Java 17 runtime and no SDK, compiler, Gradle or emulator. XML is parsed locally, source is reviewed, and the remote build/lint job is the compilation gate. Do not call the APK tested on Android hardware until those acceptance checks have actually been run.

Official references:
- https://developer.android.com/build/releases/agp-8-13-0-release-notes
- https://developer.android.com/privacy-and-security/risks/webview-unsafe-file-inclusion
- https://developer.android.com/reference/android/webkit/WebViewClient
