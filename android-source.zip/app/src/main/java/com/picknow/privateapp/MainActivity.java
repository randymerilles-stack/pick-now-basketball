package com.picknow.privateapp;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;

/** Private companion: the server owns authentication, live data, and the NO BET gate. */
public final class MainActivity extends ComponentActivity {
    private static final String HOST = "pick-now-basketball.onrender.com";
    private static final String HOME = "https://" + HOST + "/";
    private WebView web;
    private TextView error;
    private ProgressBar progress;
    private boolean wasPaused;

    private static boolean trusted(Uri uri) {
        return uri != null && "https".equalsIgnoreCase(uri.getScheme())
                && HOST.equalsIgnoreCase(uri.getHost())
                && (uri.getPort() == -1 || uri.getPort() == 443)
                && uri.getUserInfo() == null;
    }

    private static boolean externalHttps(Uri uri) {
        return uri != null && "https".equalsIgnoreCase(uri.getScheme())
                && uri.getHost() != null && uri.getUserInfo() == null;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 18, 32));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(12, 4, 12, 4);
        TextView title = new TextView(this);
        title.setText("Pick Now · Private"); title.setTextColor(Color.WHITE); title.setTextSize(17);
        title.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        Button home = new Button(this); home.setText("HOME"); home.setContentDescription("Open Pick Now home");
        home.setOnClickListener(view -> web.loadUrl(HOME));
        bar.addView(home);
        Button retry = new Button(this); retry.setText("RETRY"); retry.setContentDescription("Reload Pick Now");
        retry.setOnClickListener(view -> { error.setVisibility(View.GONE); web.reload(); });
        bar.addView(retry);
        root.addView(bar);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        root.addView(progress, new LinearLayout.LayoutParams(-1, 4));
        error = new TextView(this); error.setTextColor(Color.rgb(255, 215, 138)); error.setPadding(20, 12, 20, 12);
        error.setVisibility(View.GONE); error.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        root.addView(error);
        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        root.requestApplyInsets();
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); // Required by the authenticated live-data dashboard.
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setSafeBrowsingEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value); progress.setVisibility(value == 100 ? View.GONE : View.VISIBLE);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (trusted(uri)) return false;
                if (request.isForMainFrame() && request.hasGesture() && externalHttps(uri)) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        intent.addCategory(Intent.CATEGORY_BROWSABLE);
                        startActivity(intent);
                    } catch (ActivityNotFoundException ex) {
                        Toast.makeText(MainActivity.this, "No browser is available for this link.", Toast.LENGTH_LONG).show();
                    }
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (trusted(request.getUrl())) return null;
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", java.util.Collections.emptyMap(),
                        new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                error.setVisibility(View.GONE);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError detail) {
                if (request.isForMainFrame()) showError("Could not connect. Check your internet connection, then tap RETRY.");
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 500)
                    showError("The service is temporarily unavailable. Tap RETRY in a moment.");
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError detail) {
                handler.cancel();
                showError("Secure connection could not be verified. Access was blocked.");
            }
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { goBack(); }
        });
        // Always begin at our fixed origin. External launch intents cannot supply a URL.
        web.loadUrl(HOME);
    }

    private void showError(String message) { error.setText(message); error.setVisibility(View.VISIBLE); }
    private void goBack() { if (web.canGoBack()) web.goBack(); else finish(); }
    @Override protected void onPause() {
        super.onPause(); wasPaused = true; web.onPause(); CookieManager.getInstance().flush();
    }
    @Override protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            if (wasPaused) {
                // Start with a fresh empty dashboard after backgrounding, never retained live odds.
                wasPaused = false;
                web.loadUrl(HOME);
            }
        }
    }
    @Override protected void onDestroy() {
        if (web != null) { web.stopLoading(); web.destroy(); web = null; }
        super.onDestroy();
    }
}
